//
// Created by Ilan on 3/29/2020.
//
#include <iostream>
#include "osm.h"
#include <sys/time.h>


void foo() {
}

long nanosec(struct timeval t) { /* Calculate nanoseconds in a timeval structure */
    return ((t.tv_sec * 1000000 + t.tv_usec) * 1000);
}

double osm_operation_time(unsigned int iterations) {
    timeval t1{}, t2{};
    int x=0, y=1, z=2;
    gettimeofday(&t1, nullptr);
    for (unsigned int i = 0; i < iterations; ++i) {
        x= y + z;
        x= y + z;
        x= y + z;
        x= y + z;
        x= y + z;
        x= y + z;
        x= y + z;
        x= y + z;
        x= y + z;
        x= y + z;
    }
    gettimeofday(&t2, nullptr);
    return x*0+(double)(nanosec(t2) - nanosec(t1)) / (iterations * 10);
}

double osm_function_time(unsigned int iterations){
    timeval t1{}, t2{};
    gettimeofday(&t1, nullptr);
    for (unsigned int i = 0; i < iterations; ++i) {
        foo();
        foo();
        foo();
        foo();
        foo();
        foo();
        foo();
        foo();
        foo();
        foo();
    }
    gettimeofday(&t2, nullptr);
    return (double)(nanosec(t2) - nanosec(t1)) / (iterations * 10);

}


double osm_syscall_time(unsigned int iterations) {
    timeval t1{}, t2{};
    gettimeofday(&t1, nullptr);
    for (unsigned int i = 0; i < iterations; ++i) {
        OSM_NULLSYSCALL;
        OSM_NULLSYSCALL;
        OSM_NULLSYSCALL;
        OSM_NULLSYSCALL;
        OSM_NULLSYSCALL;
        OSM_NULLSYSCALL;
        OSM_NULLSYSCALL;
        OSM_NULLSYSCALL;
        OSM_NULLSYSCALL;
        OSM_NULLSYSCALL;
    }
    gettimeofday(&t2, nullptr);
    return (double)(nanosec(t2) - nanosec(t1)) / (iterations * 10);

}

//int main(){
//    int iterations = 100000;
//    std::cout<<"System calls time "<<osm_syscall_time(iterations)
//    <<std::endl<<"Functions time"<<osm_function_time(iterations)
//    <<std::endl<<"Operations time"<<osm_operation_time(iterations)<<std::endl;
//}